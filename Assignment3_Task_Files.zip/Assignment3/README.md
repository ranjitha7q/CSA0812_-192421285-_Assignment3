# Python Programming – Assignment 3

**Student name:** [Enter your name]  
**Register number:** [Enter your register number]  
**Python version:** Python 3.10 or later

## Tasks
1. Lists and slicing – rainfall records
2. Tuples, mutability and copying
3. Dictionaries – complaint analysis
4. Sets – elective registration
5. List comprehension – sensor cleaning
6. Nested data – railway timetable
7. Contact merging

## Run
From the repository root, run each program:
```bash
python Task01/task01_rainfall.py
python Task02/task02_tuples_copying.py
python Task03/task03_complaints.py
python Task04/task04_electives.py
python Task05/task05_sensor_cleaning.py
python Task06/task06_railway.py
python Task07/task07_contact_merge.py
```
All tasks use the Python standard library; no external packages are required.

## Notes
The sample datasets are illustrative. Replace the student name and register number before submission. Benchmark results depend on the computer and Python version, so run the scripts on your own system and record your measured values in the report.
